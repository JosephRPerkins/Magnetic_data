#! perl

use strict;
use FileHandle;


my $myline1="name:";
my $myline2="  ";
my $myline3="Set 1:";
my $myline33="Set 2:";
my $myline4="field / Oe	mag / E-3 emu / g	std dev / E-3 emu / g	temp / centigrade	time / s";
my $myline5="maximum field: 27. A";

unless (-e -d "./Analyzer-Files/"){mkdir "./Analyzer-Files/";}

foreach (glob "*.hys") {
	print "$_";
	my $IF=new FileHandle "<$_" or die "Cannot open $_: $!";
	my $ID=(split/\./, $_)[0];
	my $OF=new FileHandle ">./Analyzer-Files/$ID-ra.hys";
	
#	<$IF>;	# Read header line
	my $c=1;
	while (chomp(my $line=<$IF>)){
               
 		  my @data=split (',',$line);
                
		if ($c==1){
			printf $OF "%5s %50s %14s\n", $myline1, $ID, "weight: NA mg";
                }
                if ($c==2){
			printf $OF "%2s \n", $myline2;
                }
                if ($c==3){
			printf $OF "%6s\n", $myline3;
                }
               if ($c==4){
			print $OF  "$myline4 \n";
               }


#
#		if ($data[2]=~/^"/){
#			print "QUOTES!!\n\n";
#			$data[2]=~s/"//;
#		}
		if ($line ne ''){
                   if ($line ne 'MicroMag 2900/3900 Data File ends'){
		   if ($c>=87){
			printf $OF " %6.5f %6.5G %6.5G %10s \n",  $data[0]*10000, $data[1]*1000,  $data[1], "   1 25  0";
		   }
                   }
                }
	$c++;
	}
	print " ------> $ID-ra.hys \n";
}

foreach (glob "*.coe") {
	print "$_";
	my $IF=new FileHandle "<$_" or die "Cannot open $_: $!";
	my $ID=(split/\./, $_)[0];
	my $OF=new FileHandle ">./Analyzer-Files/$ID-ra.coe";
	
#	<$IF>;	# Read header line
	my $c=1;
	while (chomp(my $line=<$IF>)){
               
 		  my @data=split (',',$line);
                
		
		if ($c==1){
			printf $OF "%5s %50s %14s\n", $myline1, $ID, "weight: NA mg";
                }
                if ($c==2){
			print $OF  "$myline5 \n";
                }
                if ($c==3){
			printf $OF "%2s \n", $myline2;
                }
                if ($c==4){
			printf $OF "%6s\n", $myline3;
                }
                if ($c==5){
			print $OF  "$myline4 \n";
                }
#
#		if ($data[2]=~/^"/){
#			print "QUOTES!!\n\n";
#			$data[2]=~s/"//;
#		}
		if ($line ne ''){
                   if ($line ne 'MicroMag 2900/3900 Data File ends'){
		   if ($c>=94){
			printf $OF " %6.5f %6.5G %6.5G %10s \n",  $data[0]*10000, $data[1]*1000,  $data[1], "   1 25  0";
		   }
                   }
                }
	$c++;
	}
	print " ------> $ID-ra.coe \n";
}

foreach (glob "*.irm") {
	print "$_";
	my $IF=new FileHandle "<$_" or die "Cannot open $_: $!";
	my $ID=(split/\./, $_)[0];
	my $OF=new FileHandle ">./Analyzer-Files/$ID-ra.irm";
	
#	<$IF>;	# Read header line
	my $c=1;
	while (chomp(my $line=<$IF>)){
               
 		  my @data=split (',',$line);
                
		
		if ($c==1){
			printf $OF "%5s %50s %14s\n", $myline1, $ID, "weight: NA mg";
                }
                
                if ($c==2){
			printf $OF "%2s \n", $myline2;
                }
                if ($c==3){
			printf $OF "%6s\n", $myline3;
                }
                if ($c==4){
			print $OF  "$myline4 \n";
                }
#
#		if ($data[2]=~/^"/){
#			print "QUOTES!!\n\n";
#			$data[2]=~s/"//;
#		}
		if ($line ne ''){
                   if ($line ne 'MicroMag 2900/3900 Data File ends'){
		   if ($c>=90){
			printf $OF " %6.5f %6.5G %6.5G %10s \n",  $data[0]*10000, $data[1]*1000,  $data[1], "   1 25  0";
		   }
                   }
                }
	$c++;
	}
	print " ------> $ID-ra.irm \n";
}


foreach (glob "*.rmp") {
	print "$_";
	my $IF=new FileHandle "<$_" or die "Cannot open $_: $!";
	my $ID=(split/\./, $_)[0];
	my $OF=new FileHandle ">./Analyzer-Files/$ID-ra.rmp";
	
#	<$IF>;	# Read header line
	my $c=1;
	my $myswitch=0;
	while (chomp(my $line=<$IF>)){
               
 		  my @data=split (',',$line);
               
		
		if ($c==1){
			printf $OF "%5s %25s %14s\n", $myline1, $ID, "weight: NA mg";
                }
                
                if ($c==2){
			printf $OF "%2s \n", $myline2;
                }
                if ($c==3){
			printf $OF "%6s\n", $myline3;
                }
                if ($c==4){
			print $OF  "$myline4 \n";
                }
#
#		if ($data[2]=~/^"/){
#			print "QUOTES!!\n\n";
#			$data[2]=~s/"//;
#		}
#                print "$myswitch $c \n";
		if ($c>=75){
                   if ($myswitch==0){
                      if ($line ne ''){
                          printf $OF " %6.5G %6.5G %6.5G %6.5G %5s \n",  $data[2]*10000, $data[1]*1000,  $data[1], $data[3],"   0";
                      		} else {
                          $myswitch++; 
                          printf $OF "%2s \n", $myline2; 
			  printf $OF "%6s\n", $myline33;
                          print  $OF  "$myline4 \n";
		      }
	           }
                   if ($myswitch==1){
                       if ($line ne ''){
                    	    	if ($line ne 'MicroMag 2900/3900 Data File ends'){
		       	  		printf $OF " %6.5G %6.5G %6.5G %6.5G %5s \n",  $data[2]*10000, $data[1]*1000,  $data[1], $data[3],"   0";
		    		}
                   	}
                   }
                }
                   
	$c++;
	}
	print " ------> $ID-ra.rmp \n";
}